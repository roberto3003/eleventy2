exports.default = () => {
  console.log('Hello world');
  return Promise.resolve();
};
