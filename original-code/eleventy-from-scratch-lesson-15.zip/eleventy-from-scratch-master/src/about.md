---
title: 'About Issue 33'
layout: 'layouts/about.html'
permalink: '/about-us/index.html'
---

Wanna see our foosball table? Nah, only kidding. We’re a made-up
agency that are being used as the context for the Piccalilli course,
[Learn Eleventy From Scratch](https://piccalil.li/course/learn-eleventy-from-scratch/).
